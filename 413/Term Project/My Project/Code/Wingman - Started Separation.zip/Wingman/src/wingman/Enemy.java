/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wingman;

import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.util.Random;

/**
 *
 * @author netdom
 */
public class Enemy {
    Image img;
    int x;
    int y;
    int sizeX;
    int sizeY;
    int speed;
    Random gen;
    Rectangle bbox;
    boolean show;
    private final Wingman outer;

    Enemy(Image img, int speed, Random gen, final Wingman outer) {
        this.outer = outer;
        this.img = img;
        this.x = Math.abs(gen.nextInt() % (600 - 30));
        this.y = -20;
        this.speed = speed;
        this.gen = gen;
        this.show = true;
        sizeX = img.getWidth(null);
        sizeY = img.getHeight(null);
        System.out.println("w:" + sizeX + " y:" + sizeY);
    }

    public boolean collision(int x, int y, int w, int h) {
        bbox = new Rectangle(this.x, this.y, this.sizeX, this.sizeY);
        Rectangle otherBBox = new Rectangle(x, y, w, h);
        return this.bbox.intersects(otherBBox);
    }

    public Enemy getInstance() {
        return this;
    }

    public void update() throws IOException, InterruptedException {
        y += speed;
        if (outer.m1.collision(x, y, sizeX, sizeY)) {
            show = false;
            // You need to remove this one and increase score etc
            outer.gameEvents.setValue("m1_collision");
            outer.gameEvents.setValue("");
            this.reset();
            show = true;
        }
        if (outer.m2.collision(x, y, sizeX, sizeY)) {
            show = false;
            // You need to remove this one and increase score etc
            outer.gameEvents.setValue("m2_collision");
            outer.gameEvents.setValue("");
            this.reset();
            show = true;
        }
        if (outer.fire != null) {
            if (this.collision(outer.fire.x, outer.fire.y, outer.fire.width, outer.fire.height)) {
                this.show = false;
                outer.score1 += 100;
                outer.explode = new Explosion("/Resources/explosion1_", 6, this.x, this.y);
                System.out.println("Explosion created.");
                this.reset();
                show = true;
            } else {
            }
        }
        if (this.y >= 480) {
            this.reset();
            //gameEvents.setValue("test");
        } else {
            outer.gameEvents.setValue("");
        }
    }

    public void reset() {
        this.x = Math.abs(outer.generator.nextInt() % (600 - 30));
        this.y = -10;
    }

    public void draw(ImageObserver obs) {
        if (show) {
            outer.g2.drawImage(img, x, y, obs);
        }
    }
    
}
