/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wingman;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JApplet;
import javax.swing.JFrame;

/**
 *
 * @author netdom
 */
public class Wingman extends JApplet implements Runnable {

    private Thread thread;
    Image sea, bullet;
    Image playerOne, playerTwo;
    private BufferedImage bimg;
    Graphics2D g2;
    int speed = 1, move = 0;
    int score1 = 0;
    int score2 = 0;
    Random generator = new Random(1234567);
    Island I1;
    Island I2, I3;
    MyPlane m1, m2;
    Bullet fire;
    Explosion explode;
    ArrayList<Bullet> clip = new ArrayList();
    int w = 640, h = 480; // fixed size window game 
    Enemy e1;
    Enemy e2, e3;
    GameEvents gameEvents;

    @Override
    public void init() {

        setFocusable(true);
        setBackground(Color.white);
        Image island1, island2, island3, enemyOneImg, enemyTwoImg, enemyThreeImg;

        try {
            //sea = getSprite("Resources/water.png");
            String path = System.getProperty("user.dir");
            path = path + "/";
            bullet = ImageIO.read(new File(path + "Resources/bullet.png"));
            sea = ImageIO.read(new File(path + "Resources/water.png"));
            island1 = ImageIO.read(new File(path + "Resources/island1.png"));
            island2 = ImageIO.read(new File(path + "Resources/island2.png"));
            island3 = ImageIO.read(new File(path + "Resources/island3.png"));
            playerOne = ImageIO.read(new File(path + "Resources/myplane_3.png"));
            playerTwo = ImageIO.read(new File(path + "Resources/myplane_4.png"));
            enemyOneImg = ImageIO.read(new File(path + "Resources/enemy1_1.png"));
            enemyTwoImg = ImageIO.read(new File(path + "Resources/enemy2_1.png"));
            enemyThreeImg = ImageIO.read(new File(path + "Resources/enemy3_1.png"));

            I1 = new Island(island1, 100, 100, speed, generator, this);
            I2 = new Island(island2, 200, 400, speed, generator, this);
            I3 = new Island(island3, 300, 200, speed, generator, this);
            e1 = new Enemy(enemyOneImg, 1, generator, this);
            e2 = new Enemy(enemyTwoImg, 2, generator, this);
            e3 = new Enemy(enemyThreeImg, 3, generator, this);
            m1 = new MyPlane(playerOne, 50, 360, 5);
            m2 = new MyPlane(playerTwo, 425, 360, 5);
           

            // play some beats
//            try {
//                System.out.println(path);
//                Sound sound = new Sound(path + "gucci.wav");
//            } catch (MalformedURLException | LineUnavailableException | UnsupportedAudioFileException ex) {
//                Logger.getLogger(Wingman.class.getName()).log(Level.SEVERE, null, ex);
//            }

            gameEvents = new GameEvents();
            gameEvents.addObserver(m1);
            gameEvents.addObserver(m2);
            KeyControl key = new KeyControl(this);
            addKeyListener(key);
        } catch (IOException e) {
            System.out.print("No resources are found");
        }
    }

    public class GameEvents extends Observable {

        int type;
        Object event;

        public void setValue(KeyEvent e) {
            type = 1; // let's assume this means key input. 
            //Should use CONSTANT value for this when you program
            event = e;
            setChanged();
            // trigger notification
            notifyObservers(this);
        }

        public void setValue(String msg) {
            type = 2;
            event = msg;
            //System.out.println("TEST");
            setChanged();
            // trigger notification
            notifyObservers(this);
        }
    }




    public class Bullet {

        Image img;
        int x, y, height, width, power;
        Rectangle box;
        boolean show;

        Bullet(Image img, int x, int y) {
            this.img = img;
            this.x = x;
            this.y = y;
            power = 5;
            height = img.getHeight(null);
            width = img.getWidth(null);
            //box = new Rectangle(width, height);
            show = true;

        }

        public void draw(ImageObserver obs) {
            if (show){
            g2.drawImage(img, x, y, obs);
            }
        }

        // remove bullet object when off screen
        public void update(int i) {
            this.y -= 10;

            if (this.y <= -20) {
                show = false;
                clip.remove(i);
                clip.trimToSize();
            }
            //if(this != null){
            if((this.collision(e1.x, e1.y, e1.sizeX, e1.sizeY) ||
                this.collision(e2.x, e2.y, e2.sizeX, e2.sizeY) ||
                this.collision(e3.x, e3.y, e3.sizeX, e3.sizeY)) 
                    &&
                    this.show == true && this != null){                
                show = false;
                int j = clip.indexOf(this);
                clip.remove(i);
                clip.trimToSize();
            } 
            else {
           // }
            }
        }
        public boolean collision(int x, int y, int w, int h) {
            box = new Rectangle(this.x, this.y, this.width, this.height);
            Rectangle otherBBox = new Rectangle(x, y, w, h);
            return this.box.intersects(otherBBox);
        }

    }

    public class MyPlane implements Observer {

        Image img;
        int x, y, speed, width, height;
        private int health = 100;
        Rectangle bbox;
        boolean boom = false;

        MyPlane(Image img, int x, int y, int speed) {
            this.img = img;
            this.x = x;
            this.y = y;
            this.speed = speed;
            width = img.getWidth(null);
            height = img.getHeight(null);
            boom = false;
        }

        public void draw(ImageObserver obs) {
            g2.drawImage(img, x, y, obs);
        }

        public boolean collision(int x, int y, int w, int h) {
            bbox = new Rectangle(this.x, this.y, this.width, this.height);
            Rectangle otherBBox = new Rectangle(x, y, w, h);
            return this.bbox.intersects(otherBBox);
        }

        @Override
        public void update(Observable obj, Object arg) {
            GameEvents ge = (GameEvents) arg;
            if (ge.type == 1) {
                KeyEvent e = (KeyEvent) ge.event;
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_LEFT:
                        m2.x -= speed;
                        break;
                    case KeyEvent.VK_RIGHT:
                        m2.x += speed;
                        break;
                    case KeyEvent.VK_UP:
                        m2.y -= speed;
                        break;
                    case KeyEvent.VK_DOWN:
                        m2.y += speed;
                        break;
                    case KeyEvent.VK_A:
                        m1.x -= speed;
                        break;
                    case KeyEvent.VK_D:
                        m1.x += speed;
                        break;
                    case KeyEvent.VK_W:
                        m1.y -= speed;
                        break;
                    case KeyEvent.VK_S:
                        m1.y += speed;
                        break;
                    case KeyEvent.VK_ESCAPE:
                        System.exit(0);
                    default:
                        if (e.getKeyChar() == ' ' && this.equals(m1)) {
                            fire = new Bullet(bullet, m1.x + 17, m1.y);
                            clip.add(fire);
                            System.out.println("Fire 1");
                        }
                        if (e.getKeyChar() == '\n' && this.equals(m2)) {
                            fire = new Bullet(bullet, m2.x + 17, m2.y);
                            clip.add(fire);
                            System.out.println("Fire 2");
                        }

                }
            } else if (ge.type == 2) {
                String msg = (String) ge.event;
                if (msg.equals("m1_collision") && this.equals(m1)) {
                    m1.health -= 5;                    
                    System.out.println("Player 1 health: " + m1.health);
                    if (m1.health == 0) {
                        m1.boom = true;
                    }
                }
                if (msg.equals("m2_collision") && this.equals(m2)) {
                    m2.health -= 5;
                    System.out.println("Player 2 health: " + m2.health);
                    if (m2.health == 0) {
                        m2.boom = true;
                    }
                }
                if (msg.equals("test")) {
                    System.out.println("test");
                }
                    if (m1.boom && m2.boom) {

                        System.out.println("GAME OVER.");
                        System.exit(0);
                    }
                }
            }
        }

        public void drawBackGroundWithTileImage() {
            int TileWidth = sea.getWidth(this);
            int TileHeight = sea.getHeight(this);

            int NumberX = (int) (w / TileWidth);
            int NumberY = (int) (h / TileHeight);

            for (int i = -1; i <= NumberY; i++) {
                for (int j = 0; j <= NumberX; j++) {
                    g2.drawImage(sea, j * TileWidth,
                            i * TileHeight + (move % TileHeight), TileWidth,
                            TileHeight, this);
                }
            }
            move += speed;
        }

        public void drawDemo() throws IOException, InterruptedException {
            drawBackGroundWithTileImage();
            I1.update();
            I2.update();
            I3.update();
            e1.update();
            e2.update();
            e3.update();
            for (int i = 0; i < clip.size(); i++) {
                clip.get(i).update(i);
            }

            I1.draw(this);
            I2.draw(this);
            I3.draw(this);
            clip.stream().forEach((clip1) -> {
                clip1.draw(this);
            });

            m1.draw(this);
            m2.draw(this);
            e1.draw(this);
            e2.draw(this);
            e3.draw(this);
            if(explode != null){
                System.out.println("EXPLODE!");
                //explode.draw(this);            
            }
        }

        @Override
        public void paint(Graphics g) {
            if (bimg == null) {
                Dimension windowSize = getSize();
                bimg = (BufferedImage) createImage(windowSize.width,
                        windowSize.height);
                g2 = bimg.createGraphics();
            }
        try {
            drawDemo();
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(Wingman.class.getName()).log(Level.SEVERE, null, ex);
        }
            g.drawImage(bimg, 0, 0, this);
        }

        @Override
        public void start() {
            thread = new Thread(this);
            thread.setPriority(Thread.MIN_PRIORITY);
            thread.start();
        }

        @Override
        public void run() {

            Thread me = Thread.currentThread();
            while (thread == me) {
                repaint();
                try {
                    Thread.sleep(25);
                } catch (InterruptedException e) {
                    break;
                }

            }
        }

        public static void main(String argv[]) {
            final Wingman demo = new Wingman();
            demo.init();
            JFrame f = new JFrame("Scrolling Shooter");
            f.addWindowListener(new WindowAdapter() {
            });
            f.getContentPane().add("Center", demo);
            f.pack();
            f.setSize(new Dimension(640, 480));
            f.setVisible(true);
            f.setResizable(false);
            demo.start();
        }

    }
