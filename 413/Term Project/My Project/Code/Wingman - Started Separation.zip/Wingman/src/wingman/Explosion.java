/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wingman;

import java.awt.Image;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import static java.lang.Thread.sleep;
import javax.imageio.ImageIO;


/**
 *
 * @author rusky
 */
public class Explosion extends Wingman{
    Image[] frames;
    int x, y, numFrames;
    String path = System.getProperty("user.dir");
    
    /**
     * 
     * @param img: array of explosion images
     * @param x: x coordinate
     * @param y: y coordinate
     * @throws IOException if image file is not found
     */
    Explosion(String name, int numFrames, int x, int y) throws IOException{
        this.x = x;
        this.y = y;
        this.numFrames = numFrames;
        frames = new Image[1];
        
               
        // load images into explosion object 
        //for(int i=1; i <= 1; i++){
            frames[0] = ImageIO.read(new File(path + name + 1 + ".png"));
            System.out.println(path + name + 1 + ".png");
            
       // }
    }
    
    public void draw(ImageObserver obs) throws InterruptedException, IOException{
        
        //this.test = ImageIO.read(new File("/home/netdom/Dropbox/Fall 2014/413/Term Project/My Project/Code/Wingman/Resources/explosion1_1.png"));
        //for(int i=0; i < 1; i++){
            //sleep(1);
            //System.out.println("Draw: " + this.frames[0].toString());
        g2.drawImage(this.frames[0], x, y, obs);
        //}
    }
    
    
    public void update() throws InterruptedException{
            
    }
    
}
